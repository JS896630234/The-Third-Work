#include<stdio.h>
#include<stdlib.h>
#include"stack.h"


int main()
{
	SqStack S;
	InitStack(S);
	welcome(S);
	return 0;
}