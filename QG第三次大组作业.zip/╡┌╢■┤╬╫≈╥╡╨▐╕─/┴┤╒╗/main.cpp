
#include<iostream>
#include "stack.h"
using namespace std;
int main()
{
	PSTACK S;
	InitStack(S);
	welcome(S);
	return 0;
}
