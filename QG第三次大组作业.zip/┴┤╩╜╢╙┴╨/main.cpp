#include"LinkQueue.h"
int main() {
	LinkQueue Q;
	InitQueue(Q);
	Welcome(Q);
	return 0;
}