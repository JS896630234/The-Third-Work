#pragma once
#include<iostream>
using namespace std;


const int MAXSIZE = 100;

typedef int ElemType;
//�ڵ�
typedef struct node {
	ElemType data;
	struct node* next;
}QNode, * QueuePtr;

typedef struct Queue {
	QueuePtr front;
	QueuePtr rear;
}QUEUE, LinkQueue;
enum Status {
	ERROR, OK
};

enum BOOL { FALSE, TRUE };


bool InitQueue(LinkQueue& Q);				//��ʼ��
int LengthQueue(LinkQueue Q);				//�󳤶�
BOOL IsEmptyQueue(LinkQueue Q);				//�жϿ�
bool EnQueue(LinkQueue& Q);					//���
Status DeQueue(LinkQueue& Q);				//����
Status GetHeadQueue(LinkQueue Q);			//�鿴��ͷ
Status DestroyQueue(LinkQueue& Q);			//����
Status ClearQueue(LinkQueue& Q);			//���
Status TraverseQueue(LinkQueue Q);			//����
void Welcome(LinkQueue &Q);