#pragma once
#include <stdio.h>
#include<stdlib.h>

const int MAXSIZE = 10;

typedef int ElemType;
typedef struct {
	ElemType* base;
	int front;
	int rear;
}SqQueue;

enum Status { ERROR, OK };

enum BOOL { FALSE, TRUE };

Status InitQueue(SqQueue& Q);				//��ʼ��
int LengthQueue(SqQueue Q);				//�󳤶�
BOOL IsEmptyQueue(SqQueue Q);			//�жϿ�
Status EnQueue(SqQueue& Q);				//���
Status DeQueue(SqQueue& Q);				//����
Status GetHeadQueue(SqQueue Q);			//�鿴��ͷ
Status DestroyQueue(SqQueue& Q);		//����
Status ClearQueue(SqQueue& Q);			//���
Status TraverseQueue(SqQueue& Q);		//����
void Welcome(SqQueue& Q);