#include"SqQueue.h"
int main()
{
	SqQueue Q;
	InitQueue(Q);
	Welcome(Q);
	return 0;
}